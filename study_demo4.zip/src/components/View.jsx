import React, { useContext } from "react";
import { storeContext } from "../store.js";

function View() {
  const { count } = useContext(storeContext);

  return <p>{count}</p>;
}

export default View;
