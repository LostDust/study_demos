import React, { useContext } from "react";
import { storeContext } from "../store.js";

function Ctrl() {
  const { count, dispatch } = useContext(storeContext);

  function addCount() {
    dispatch({
      type: "UPDATE",
      value: "count",
      count: count + 1
    });
  }

  return <button onClick={addCount}>add</button>;
}

export default Ctrl;
