import React, { useReducer } from "react";
import { storeContext, reducer, initStore } from "./store.js";

function Provider({ children }) {
  const [store, dispatch] = useReducer(reducer, initStore);

  return (
    <storeContext.Provider value={{ ...store, dispatch }}>
      {children}
    </storeContext.Provider>
  );
}

export default Provider;
