import { createContext } from "react";

const storeContext = createContext();

function reducer(state, action) {
  const newState = Object.assign({}, state);
  switch (action.type) {
    case "UPDATE":
      newState[action.value] = action[action.value];
      return newState;
    default:
      return state;
  }
}

const initStore = {
  count: 233
};

export { storeContext, reducer, initStore };
