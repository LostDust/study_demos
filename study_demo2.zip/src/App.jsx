import React, { useReducer } from "react";
import { reduxContext, reducer } from "./store";
import View from "./components/View";
import Ctrl from "./components/Ctrl";

function App() {
  const [count, dispatch] = useReducer(reducer, 233);
  const store = { count, dispatch };

  return (
    <reduxContext.Provider value={store}>
      <View />
      <Ctrl />
    </reduxContext.Provider>
  );
}

export default App;
