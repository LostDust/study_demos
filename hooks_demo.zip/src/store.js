import { createContext } from "react";

const reduxContext = createContext();

export default reduxContext;
