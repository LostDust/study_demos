import React, { useState } from "react";
import reduxContext from "./store";
import View from "./components/View";
import Ctrl from "./components/Ctrl";

function App() {
  const [count, setCount] = useState(233);
  const store = { count, setCount };

  return (
    <reduxContext.Provider value={store}>
      <View />
      <Ctrl />
    </reduxContext.Provider>
  );
}

export default App;
