import React, { useContext } from "react";
import reduxContext from "../store";

function View() {
  const { count, setCount } = useContext(reduxContext);

  return <div>{count}</div>;
}

export default View;
