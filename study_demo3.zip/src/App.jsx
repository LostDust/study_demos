import React from "react";
import Provider from "./Provider";
import View from "./components/View";
import Ctrl from "./components/Ctrl";

function App() {
  return (
    <Provider>
      <View />
      <Ctrl />
    </Provider>
  );
}

export default App;
