import React, { useReducer } from "react";
import { reduxContext, reducer, initStore } from "./store";

function Provider({ children }) {
  const store = {};
  const storeDispatch = {};
  Object.keys(initStore).forEach(item => {
    const [value, dispatch] = useReducer(reducer, initStore[item]);
    store[item] = value;
    storeDispatch[item] = dispatch;
  });
  store.dispatch = storeDispatch;

  return (
    <reduxContext.Provider value={store}>{children}</reduxContext.Provider>
  );
}

export default Provider;
