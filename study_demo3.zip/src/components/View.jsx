import React, { useContext } from "react";
import { reduxContext } from "../store";

function View() {
  const { count } = useContext(reduxContext);

  return <p>{count}</p>;
}

export default View;
