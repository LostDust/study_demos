import React, { useContext } from "react";
import { reduxContext } from "../store";

function Ctrl() {
  const { count, dispatch } = useContext(reduxContext);
  function add() {
    dispatch.count({
      type: "UPDATE",
      value: count + 1
    });
  }

  return <button onClick={add}>add</button>;
}

export default Ctrl;
